CREATE TABLE Caregivers (
    Username varchar(255),
    Salt BINARY(16),
    Hash BINARY(16),
    PRIMARY KEY (Username)
);

CREATE TABLE Patients (
    Username varchar(255),
    Salt BINARY(16),
    Hash BINARY(16),
    PRIMARY KEY (Username)
);

CREATE TABLE Vaccines (
    Name varchar(255),
    Doses int,
    PRIMARY KEY (Name)
);

CREATE TABLE Availabilities (
    AvailableTime date,
    Username varchar(255) REFERENCES Caregivers,
    Taken varchar(1),
    PRIMARY KEY (AvailableTime, Username)
);

CREATE TABLE Appointment (
    Patient varchar(255) REFERENCES Patients(Username),
    AppointmentID int,
    Vaccine varchar(255) REFERENCES Vaccines(Name),
    AvailableTime date,
	Username varchar(255),
    PRIMARY KEY (AppointmentID),
    FOREIGN KEY (AvailableTime, Username) REFERENCES Availabilities(AvailableTime, Username)
);