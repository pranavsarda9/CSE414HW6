import sys
from model.Vaccine import Vaccine
from model.Caregiver import Caregiver
from model.Patient import Patient
from util.Util import Util
from db.ConnectionManager import ConnectionManager
import pymssql
import datetime
import random


'''
objects to keep track of the currently logged-in user
Note: it is always true that at most one of currentCaregiver and currentPatient is not null
        since only one user can be logged-in at a time
'''
current_patient = None

current_caregiver = None


def create_patient(tokens):
    if len(tokens) != 3:
        print("Please try again!")
        return

    username = tokens[1]
    password = tokens[2]

    if username_exists_patient(username):
        print("Username taken, try again!")
        return

    salt = Util.generate_salt()
    hash = Util.generate_hash(password, salt)

    # create the caregiver
    try:
        patient = Patient(username, salt=salt, hash=hash)
        # save to caregiver information to our database
        patient.save_to_db()
        print(" *** Account created successfully *** ")
    except pymssql.Error:
        print("Create failed")
        return


def create_caregiver(tokens):
    # create_caregiver <username> <password>
    # check 1: the length for tokens need to be exactly 3 to include all information (with the operation name)
    if len(tokens) != 3:
        print("Please try again!")
        return

    username = tokens[1]
    password = tokens[2]
    # check 2: check if the username has been taken already
    if username_exists_caregiver(username):
        print("Username taken, try again!")
        return

    salt = Util.generate_salt()
    hash = Util.generate_hash(password, salt)

    # create the caregiver
    try:
        caregiver = Caregiver(username, salt=salt, hash=hash)
        # save to caregiver information to our database
        caregiver.save_to_db()
        print(" *** Account created successfully *** ")
    except pymssql.Error:
        print("Create failed")
        return


def username_exists_caregiver(username):
    cm = ConnectionManager()
    conn = cm.create_connection()

    select_username = "SELECT * FROM Caregivers WHERE Username = %s"
    try:
        cursor = conn.cursor(as_dict=True)
        cursor.execute(select_username, username)
        #  returns false if the cursor is not before the first record or if there are no rows in the ResultSet.
        for row in cursor:
            return row['Username'] is not None
    except pymssql.Error:
        print("Error occurred when checking username")
        cm.close_connection()
    cm.close_connection()
    return False

def username_exists_patient(username):
    cm = ConnectionManager()
    conn = cm.create_connection()

    select_username = "SELECT * FROM Patients WHERE Username = %s"
    try:
        cursor = conn.cursor(as_dict=True)
        cursor.execute(select_username, username)
        #  returns false if the cursor is not before the first record or if there are no rows in the ResultSet.
        for row in cursor:
            return row['Username'] is not None
    except pymssql.Error:
        print("Error occurred when checking username")
        cm.close_connection()
    cm.close_connection()
    return False

def login_patient(tokens):
    # login_caregiver <username> <password>
    # check 1: if someone's already logged-in, they need to log out first
    global current_patient
    if current_caregiver is not None or current_patient is not None:
        print("Already logged-in!")
        return

    # check 2: the length for tokens need to be exactly 3 to include all information (with the operation name)
    if len(tokens) != 3:
        print("Please try again!")
        return

    username = tokens[1]
    password = tokens[2]

    patient = None
    try:
        patient = Patient(username, password=password).get()
    except pymssql.Error:
        print("Error occurred when logging in")

    # check if the login was successful
    if patient is None:
        print("Please try again!")
    else:
        print("Patient logged in as: " + username)
        current_patient = patient


def login_caregiver(tokens):
    # login_caregiver <username> <password>
    # check 1: if someone's already logged-in, they need to log out first
    global current_caregiver
    if current_caregiver is not None or current_patient is not None:
        print("Already logged-in!")
        return

    # check 2: the length for tokens need to be exactly 3 to include all information (with the operation name)
    if len(tokens) != 3:
        print("Please try again!")
        return

    username = tokens[1]
    password = tokens[2]

    caregiver = None
    try:
        caregiver = Caregiver(username, password=password).get()
    except pymssql.Error:
        print("Error occurred when logging in")

    # check if the login was successful
    if caregiver is None:
        print("Please try again!")
    else:
        print("Caregiver logged in as: " + username)
        current_caregiver = caregiver


def search_caregiver_schedule(tokens):
    global current_caregiver
    global current_patient
    if current_caregiver is None and current_patient is None:
        print("Please log in first!")
        return

    # check 2: the length for tokens need to be exactly 3 to include all information (with the operation name)
    if len(tokens) != 2:
        print("Please try again!")
        return

    date = tokens[1]

    get_all_vaccines = "SELECT Name, Doses FROM vaccines"
    get_all_caregivers = "SELECT Username FROM Availabilities WHERE Taken = 'N' AND AvailableTime = %s"

    cm = ConnectionManager()
    conn = cm.create_connection()
    cursor = conn.cursor(as_dict=True)


    try:
        cursor.execute(get_all_caregivers,date)
        first = cursor.fetchone()
        if first is None:
            print("There are no Availabilities for this Date")
            return
        else:
            print("Caregiver Name: " + str(first['Username']))
        for row in cursor:
            print("Caregiver Name: " + str(row['Username']))
    except pymssql.Error:
            print("Error occurred while getting Names from Availabilities")

    try:
        cursor.execute(get_all_vaccines)
        for row in cursor:
            print("Vaccine Name: " + str(row['Name']) + ", Available Doses: " + str(row['Doses']))
    except pymssql.Error:
        print("Error occurred when getting details from Vaccines")



def reserve(tokens):

    # check 1: if someone's already logged-in, they need to log out first
    global current_patient
    global current_caregiver

    if current_patient is None or current_caregiver is not None:
        print("Log in as Patient!")
        return

    # check 2: the length for tokens need to be exactly 3 to include all information (with the operation name)
    if len(tokens) != 3:
        print("Please try again!")
        return

    cm = ConnectionManager()
    conn = cm.create_connection()
    cursor = conn.cursor(as_dict=True)

    get_vaccine_doses = "SELECT Doses FROM Vaccines WHERE Name = %s"
    get_caregivers = "SELECT Username FROM Availabilities WHERE TAKEN = 'N' AND AvailableTime = %s"
    get_goodID = "SELECT * FROM Appointment WHERE AppointmentID = %d"
    check_patient_date = "SELECT * FROM Appointment WHERE AvailableTime = %s AND Patient = %s"

    date = tokens[1]
    vaccine = tokens[2]

    try:
        cursor.execute(check_patient_date, (date, current_patient.get_username()))
        first = cursor.fetchone()
        if first is not None:
            print("Already made appointment on this date!")
            return
    except pymssql.Error:
        print("Error occurred while Checking Date for Patient")
        return

    try:
        cursor.execute(get_vaccine_doses, vaccine)
        first = cursor.fetchone()
        if first is None:
            print("Vaccine does not exist in database!")
            return
        if first['Doses'] < 1:
            print("Not enough doses of this Vaccine currently")
            return
    except pymssql.Error:
        print("Error occurred while getting Doses from Vaccines")
        return

    names = []
    try:
        cursor.execute(get_caregivers,date)
        first = cursor.fetchone()
        if first is None:
            print("Not possible to book this Date")
            return
        else:
            names.append(str(first['Username']))
        for row in cursor:
            names.append(str(row['Username']))
    except pymssql.Error:
        print("Error occurred while getting Caregivers from Availabilities")

    if len(names) == 1:
        final_name = names[0]
    else:
        final_name = names[random.randint(0,len(names) - 1)]

    ap_ID = random.randint(0, 100000000)
    good_ID = True
    while good_ID:
        try:
            cursor.execute(get_goodID, ap_ID)
            first = cursor.fetchone()
            if first is None:
                good_ID = False
            else:
                ap_ID = random.randint(0,100000000)
        except pymssql.Error:
            print("Error occurred while getting ID from Appointment")

    AppointmentStatement = "INSERT INTO Appointment VALUES (%s, %s, %s, %d, %s)"
    try:
        cursor.execute(AppointmentStatement, (current_patient.get_username(), ap_ID, vaccine, date, final_name))
        conn.commit()
    except pymssql.Error:
        print("Error occurred while inserting Appointment Values Into Appointment")
        return


    NoLongerAvailable = "UPDATE Availabilities SET Taken = 'Y' WHERE Username = %s AND AvailableTime = %s"
    try:
        cursor.execute(NoLongerAvailable, (final_name, date))
        conn.commit()
    except pymssql.Error:
        print("Error occurred while Updating Availabilities")
        return

    GetDoses = "Select * FROM Vaccines WHERE Name = %s"
    try:
        cursor.execute(GetDoses, (vaccine))
    except pymssql.Error:
        print("Error occurred while Getting Vaccines")
        return

    try:
        first = cursor.fetchone()
        vax = Vaccine(vaccine, first['Doses']).get()
        vax.decrease_available_doses(1)
    except pymssql.Error:
        print("Error occurred when reducing doses")
        return

    print("Caregiver: " + final_name + ", AppointmentID: " + str(ap_ID))

def upload_availability(tokens):
    #  upload_availability <date>
    #  check 1: check if the current logged-in user is a caregiver
    global current_caregiver
    if current_caregiver is None:
        print("Please login as a caregiver first!")
        return

    # check 2: the length for tokens need to be exactly 2 to include all information (with the operation name)
    if len(tokens) != 2:
        print("Please try again!")
        return

    cm = ConnectionManager()
    conn = cm.create_connection()
    cursor = conn.cursor(as_dict=True)

    date = tokens[1]
    # assume input is hyphenated in the format mm-dd-yyyy

    check_availability = "SELECT * FROM Availabilities WHERE AvailableTime = %s AND Username = %s"

    try:
        cursor.execute(check_availability, (date, current_caregiver.get_username()))
        first = cursor.fetchone()
        if first is not None:
            print("Availability already uploaded!")
            return
    except pymssql.Error as db_err:
        print("Error occurred when checking availability")

    try:
        current_caregiver.upload_availability(date)
        print("Availability uploaded!")
    except ValueError:
        print("Please enter a valid date!")
    except pymssql.Error as db_err:
        print("Error occurred when uploading availability")


def cancel(tokens):
    """
    TODO: Extra Credit
    """
    pass


def add_doses(tokens):
    #  add_doses <vaccine> <number>
    #  check 1: check if the current logged-in user is a caregiver
    global current_caregiver
    if current_caregiver is None:
        print("Please login as a caregiver first!")
        return

    #  check 2: the length for tokens need to be exactly 3 to include all information (with the operation name)
    if len(tokens) != 3:
        print("Please try again!")
        return

    vaccine_name = tokens[1]
    doses = int(tokens[2])
    vaccine = None
    try:
        vaccine = Vaccine(vaccine_name, doses).get()
    except pymssql.Error:
        print("Error occurred when adding doses")

    # check 3: if getter returns null, it means that we need to create the vaccine and insert it into the Vaccines
    #          table

    if vaccine is None:
        try:
            vaccine = Vaccine(vaccine_name, doses)
            vaccine.save_to_db()
        except pymssql.Error:
            print("Error occurred when adding doses")
    else:
        # if the vaccine is not null, meaning that the vaccine already exists in our table
        try:
            vaccine.increase_available_doses(doses)
        except pymssql.Error:
            print("Error occurred when adding doses")

    print("Doses updated!")


def show_appointments(tokens):
    global current_caregiver
    global current_patient

    if current_caregiver is None and current_patient is None:
        print("Please log in first!")
        return

    cm = ConnectionManager()
    conn = cm.create_connection()
    cursor = conn.cursor(as_dict=True)

    if current_caregiver is None:
        get_Appointment = "SELECT Patient, AppointmentID, Vaccine, AvailableTime FROM Appointment WHERE Patient = %s"
        try:
            cursor.execute(get_Appointment, current_patient.get_username())
            first = cursor.fetchone()
            if first is None:
                print("No Appointments Scheduled!")
                return
            else:
                print("Date: " + str(first['AvailableTime']) + ", Patient Name: " + str(first['Patient']) + ", Appointment ID: " + str(first['AppointmentID']) + ", Vaccine Name: " + str(first['Vaccine']))
        except pymssql.Error:
            print("Error occurred while getting Values from Appointment")
    else:
        get_Appointment = "SELECT AvailableTime, Username, AppointmentID, Vaccine FROM Appointment WHERE Username = %s"
        try:
            cursor.execute(get_Appointment, current_caregiver.get_username())
            first = cursor.fetchone()
            if first is None:
                print("No Appointments Scheduled!")
                return
            else:
                print("Date: " + str(first['AvailableTime']) + ", Caregiver Name: " + str(first['Username']) + ", Appointment ID: " + str(first['AppointmentID']) + ", Vaccine Name: " + str(first['Vaccine']))
        except pymssql.Error:
            print("Error occurred while getting Values from Appointment")

def logout(tokens):
    global current_caregiver
    global current_patient

    if current_caregiver is None and current_patient is None:
        print("Already Logged Out!")
        return

    if current_caregiver is not None:
        current_caregiver = None
        print("Logged Out!")
        return

    if current_patient is not None:
        current_patient = None
        print("Logged Out!")
        return

def start():
    stop = False
    while not stop:
        print()
        print(" *** Please enter one of the following commands *** ")
        print("> create_patient <username> <password>")  # //TODO: implement create_patient (Part 1)
        print("> create_caregiver <username> <password>")
        print("> login_patient <username> <password>")  #// TODO: implement login_patient (Part 1)
        print("> login_caregiver <username> <password>")
        print("> search_caregiver_schedule <date>")  #// TODO: implement search_caregiver_schedule (Part 2)
        print("> reserve <date> <vaccine>") #// TODO: implement reserve (Part 2)
        print("> upload_availability <date>")
        print("> cancel <appointment_id>") #// TODO: implement cancel (extra credit)
        print("> add_doses <vaccine> <number>")
        print("> show_appointments")  #// TODO: implement show_appointments (Part 2)
        print("> logout") #// TODO: implement logout (Part 2)
        print("> Quit")
        print()
        response = ""
        print("> Enter: ", end='')

        try:
            response = str(input())
        except ValueError:
            print("Type in a valid argument")
            break

        response = response.lower()
        tokens = response.split(" ")
        if len(tokens) == 0:
            ValueError("Try Again")
            continue
        operation = tokens[0]
        if operation == "create_patient":
            create_patient(tokens)
        elif operation == "create_caregiver":
            create_caregiver(tokens)
        elif operation == "login_patient":
            login_patient(tokens)
        elif operation == "login_caregiver":
            login_caregiver(tokens)
        elif operation == "search_caregiver_schedule":
            search_caregiver_schedule(tokens)
        elif operation == "reserve":
            reserve(tokens)
        elif operation == "upload_availability":
            upload_availability(tokens)
        elif operation == cancel:
            cancel(tokens)
        elif operation == "add_doses":
            add_doses(tokens)
        elif operation == "show_appointments":
            show_appointments(tokens)
        elif operation == "logout":
            logout(tokens)
        elif operation == "quit":
            print("Thank you for using the scheduler, Goodbye!")
            stop = True
        else:
            print("Invalid Argument")


if __name__ == "__main__":
    '''
    // pre-define the three types of authorized vaccines
    // note: it's a poor practice to hard-code these values, but we will do this ]
    // for the simplicity of this assignment
    // and then construct a map of vaccineName -> vaccineObject
    '''

    # start command line
    print()
    print("Welcome to the COVID-19 Vaccine Reservation Scheduling Application!")

    start()
